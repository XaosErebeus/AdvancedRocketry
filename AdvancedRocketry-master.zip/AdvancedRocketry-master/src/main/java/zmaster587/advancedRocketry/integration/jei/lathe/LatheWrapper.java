package zmaster587.advancedRocketry.integration.jei.lathe;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class LatheWrapper extends MachineRecipe {

	LatheWrapper(IRecipe rec) {
		super(rec);
	}

}
