package zmaster587.advancedRocketry.integration.jei.blastFurnace;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class BlastFurnaceWrapper extends MachineRecipe {

	BlastFurnaceWrapper(IRecipe rec) {
		super(rec);
	}

}
