package zmaster587.advancedRocketry.integration.jei.chemicalReactor;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class ChemicalReactorlWrapper extends MachineRecipe {

	ChemicalReactorlWrapper(IRecipe rec) {
		super(rec);
	}

}
