package zmaster587.advancedRocketry.integration.jei;

import mezz.jei.api.recipe.IRecipeHandler;
import mezz.jei.api.recipe.IRecipeWrapper;

public class MachineTemplate implements IRecipeHandler<MachineRecipe> {

	@Override
	public Class<MachineRecipe> getRecipeClass() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRecipeCategoryUid(MachineRecipe recipe) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public IRecipeWrapper getRecipeWrapper(MachineRecipe recipe) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isRecipeValid(MachineRecipe recipe) {
		// TODO Auto-generated method stub
		return false;
	}

}
