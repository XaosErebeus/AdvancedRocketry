package zmaster587.advancedRocketry.integration.jei.rollingMachine;

import zmaster587.advancedRocketry.integration.jei.MachineRecipe;
import zmaster587.libVulpes.interfaces.IRecipe;

public class RollingMachineWrapper extends MachineRecipe {

	RollingMachineWrapper(IRecipe rec) {
		super(rec);
	}

}
